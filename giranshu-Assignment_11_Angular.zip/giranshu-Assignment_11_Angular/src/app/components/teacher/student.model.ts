export class StudentData {
    id: number = 0;
    rollno: number = 0;
    name: string = '';
    dob: string = '';
    score: number = 0;
    skill: string = '';

}